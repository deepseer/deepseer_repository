function RaidIcon(i)
	if i>=1 and i<=8 then
		return "{rt"..i.."}"
	else
		return ""
	end
end

function GetSendTargetString(SendTargetValue)
	if SendTargetValue==0 then
		return "LOCAL"
	elseif SendTargetValue==1 then
		return "SAY"
	elseif SendTargetValue==2 then
		return "YELL"
	elseif SendTargetValue==3 then
		return "PARTY"
	elseif SendTargetValue==4 then
		return "RAID"
	end
	return "LOCAL"
end

function SendChatMessageTo(str, target)
	-- AceSparkBot:Print(str.." "..target)
	if target>0 then
		SendChatMessage(str, GetSendTargetString(target));
	else
		AceSparkBot:Print(str)
	end
end