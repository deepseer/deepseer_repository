AceSparkBot = LibStub("AceAddon-3.0"):NewAddon("AceSparkBot", "AceConsole-3.0")
local AceGUI = LibStub("AceGUI-3.0")


function AceSparkBot:OnInitialize()
	-- Code that you want to run when the addon is first loaded goes here.
	self:Print("AceSparkBot:OnInitialize()")
end

function AceSparkBot:OnEnable()
	-- Called when the addon is enabled
	self:Print("AceSparkBot:OnEnable()")
end

function AceSparkBot:OnDisable()
	-- Called when the addon is disabled
	self:Print("AceSparkBot:OnDisable()")
end

AceSparkBot:RegisterChatCommand("asb", "AceSparkBotSlashProcessorFunc")

function AceSparkBot:AceSparkBotSlashProcessorFunc(input)
	self:Print("cmd = "..input)
	if input=="open" then
		if MainFrame_enabled then
			self:Print("MainFrame already open")
		else
			MainFrame = CreateMainFrame()
		end
	end
	if input=="close" then
		if MainFrame_enabled then
			AceGUI:Release(MainFrame)
			MainFrame_enabled = false
		else
			self:Print("MainFrame already closed")
		end
	end
	if input=="reload" or input=="rl" then
		if MainFrame_enabled then
			AceGUI:Release(MainFrame)
			MainFrame_enabled = false
			MainFrame = CreateMainFrame()
		end
	end
end

