function classTagToClassColor(classTag)
	if (classTag == "WARRIOR") then
		return "|cFFC79C6E"
	elseif (classTag == "PALADIN") then
		return "|cFFF58CBA"
	elseif (classTag == "HUNTER") then
		return "|cFFABD473"
	elseif (classTag == "ROGUE") then
		return "|cFFFFF569"
	elseif (classTag == "PRIEST") then
		return "|cFFFFFFFF"
	elseif (classTag == "DEATHKNIGHT") then
		return "|cFFC41F3B"
	elseif (classTag == "SHAMAN") then
		return "|cFF0070DE"
	elseif (classTag == "MAGE") then
		return "|cFF69CCF0"
	elseif (classTag == "WARLOCK") then
		return "|cFF9482C9"
	elseif (classTag == "MONK") then
		return "|cFF00FF96"
	elseif (classTag == "DRUID") then
		return "|cFFFF7D0A"
	elseif (classTag == "DEMONHUNTER") then
		return "|cFFA330C9"
	elseif (classTag == "") then
		return "|cFFFFFFFF"
	end
	return "|cFFBBBBBB"
end

function raidPlayerClassColor(value, groupType)
	if groupType==nil then
		groupType = "raid"
	end
	local localizedClass, classTag, classIndex = UnitClass(groupType..value);
	return classTagToClassColor(classTag)
end

function localizedClassNameInfo(localizedName)
	for i = 1, GetNumClasses() do
		local className, classTag, classID = GetClassInfo(i)
		if className == localizedName then
			classColor = classTagToClassColor(classTag)
			return classTag, classID, classColor
		end
	end
end


noColor = "|cFFFFFFFF" -- white | plain
deadColor = "|cFFFF0000" -- red | dead, no healer warning
offlineColor = "|cFF808080" -- gray 50%
groupColor = "|cFFE6AC00" -- gold

function getPlayerName(value, showServer, showGroup, showRaidID, showStatus, showColor)
	local playerName = GetUnitName("raid"..value, showServer)
	local name, rank, subgroup, level, class, fileName,
		zone, online, isDead, role, isML, combatRole = GetRaidRosterInfo(value)
	if playerName == nil then
		if showColor then
			playerName = "ERROR"..noColor.."("..value..")"
		else
			playerName = "ERROR("..value..")"
		end
		return playerName
	end
	if showColor then
		if showGroup then
			playerName = playerName..groupColor.."{"..L["group"]..subgroup.."}"..noColor
		end
		if showRaidID then
			playerName = playerName..noColor.."("..value..")"
		end
		if showStatus then
			if isDead then
				playerName = playerName..deadColor..L["dead"]..noColor
			end
			if not online then
				if isDead then playerName = playerName.."," end
				playerName = playerName..offlineColor..L["dc"]..noColor
			end
		end
	else
		if showGroup then
			playerName = playerName.."{"..L["group"]..subgroup.."}"
		end
		if showRaidID then
			playerName = playerName.."("..value..")"
		end
		if showStatus then
			if isDead then
				playerName = playerName..L["dead"]
			end
			if not online then
				if isDead then playerName = playerName.."," end
				playerName = playerName..L["dc"]
			end
		end
	end
	return playerName
end

function print_players_array(arr, showRaidID, showStatus, showColor)
	if (arr==nil) then
		return "";
	end
	local str = ""
	if showColor then
		for index, value in pairs(arr) do
			str = str..raidPlayerClassColor(value)..getPlayerName(value, true, true, showRaidID, showStatus, true)..", "
		end
	else
		for index, value in pairs(arr) do
			str = str..getPlayerName(value, true, true, showRaidID, showStatus, false)..", "
		end
	end
	if (str[string.len(str)]==" ") then
		str = str:sub(1, -3)
	end
	return str
end