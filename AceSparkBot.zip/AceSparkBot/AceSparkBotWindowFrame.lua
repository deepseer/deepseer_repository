local AceGUI = LibStub("AceGUI-3.0")

--MainFrame = AceGUI:Create("Frame")
MainFrame = {}
MainFrame_enabled = false

SparkBotRaidIconFirst = 4
SparkBotRaidIconLast = 8
MaxColorNum = 6

SendTargetValue = 0

PlayerButtonSetGroup = {}

BotColorLabel = {"|cFFFF0000紅 |cFFFFFFFF- 1", "|cFFFF00FF紫 |cFFFFFFFF- 2",
	"|cFF00FF00綠 |cFFFFFFFF- 3", "|cFFFFFF00黃 |cFFFFFFFF- 4", "|cFF0000FF藍 |cFFFFFFFF- 5", "|cFF808080X"}
BotColorText = {"紅", "紫", "綠", "黃", "藍", "無圖標"}

function CreateMainFrame()
	MainFrame = AceGUI:Create("Frame")
	
	MainFrame.CreateFrame = function()
		MainFrame:SetTitle("Ace SparkBot Frame")
		MainFrame:SetStatusText("AceGUI-3.0 Test Container Frame - SparkBot")
		MainFrame:SetCallback("OnClose", function(widget) AceGUI:Release(widget) MainFrame_enabled=false end)
		MainFrame:SetLayout("List")
	end
	
	MainFrame.GetEditboxText = function()
		return editbox:GetText()
	end
	
	MainFrame.GetSendTarget = function()
		return slider:GetValue()
	end
	
	MainFrame:CreateFrame()
	MainFrame_enabled = true

	SendTargetLabel = AceGUI:Create("Label")
	SendTargetLabel:SetText(GetSendTargetString(SendTargetValue))
	MainFrame:AddChild(SendTargetLabel)

	SendTargetSlider = AceGUI:Create("Slider")
	SendTargetSlider:SetLabel("To:")
	SendTargetSlider:SetValue(SendTargetValue)
	SendTargetSlider:SetSliderValues(0, 4, 1)
	SendTargetSlider:SetCallback("OnMouseUp", function(v)
			SendTargetValue = floor(SendTargetSlider:GetValue() + 0.5)
			SendTargetLabel:SetText(GetSendTargetString(SendTargetValue))
			SendTargetSlider:SetValue(SendTargetValue)
			
		end)
	MainFrame:AddChild(SendTargetSlider)
	
	GroupFrame = AceGUI:Create("SimpleGroup")
	
	for raidIndex = SparkBotRaidIconFirst, SparkBotRaidIconLast do
		RaidIconsAndColorsFrame = AceGUI:Create("SimpleGroup")
		RaidIconsAndColorsFrame:SetLayout("Flow")
		RaidIconsAndColorsFrame:SetWidth(450)
		
		RaidTargetIconLabel = AceGUI:Create("Label")
		RaidTargetIconLabel:SetWidth(50)

		RaidTargetIconLabel:SetImage("Interface/AddOns/AceSparkBot/raidicons/32rt"..raidIndex)

		RaidIconsAndColorsFrame:AddChild(RaidTargetIconLabel)

		PlayerButtonSetGroup[raidIndex] = {}
		for i = 1, MaxColorNum do
			PlayerButtonSetGroup[raidIndex][i] = AceGUI:Create("Button")
			PlayerButtonSetGroup[raidIndex][i]:SetText(BotColorLabel[i])
			PlayerButtonSetGroup[raidIndex][i]:SetWidth(50)
			PlayerButtonSetGroup[raidIndex][i]:SetHeight(40)
			RaidIconsAndColorsFrame:AddChild(PlayerButtonSetGroup[raidIndex][i])
		end
		for i = 1, MaxColorNum do
			PlayerButtonSetGroup[raidIndex][i]:SetCallback("OnClick", function(widget)
					SendChatMessageTo(RaidIcon(raidIndex)..RaidIcon(raidIndex)..
						RaidIcon(raidIndex).." "..BotColorText[i], SendTargetValue);
				end)
		end

		GroupFrame:AddChild(RaidIconsAndColorsFrame)
	end
	
	MainFrame:AddChild(GroupFrame)
	
	FinishLineFrame = AceGUI:Create("SimpleGroup")
	FinishLineFrame:SetLayout("Flow")
	FinishLineFrame:SetWidth(450)
	
	FinishButton = AceGUI:Create("Button")
	FinishButton:SetWidth(300)
	FinishButton:SetHeight(50)
	FinishButton:SetText("完成！")
	FinishButton:SetCallback("OnClick", function(widget)
			SendChatMessageTo("完成！", SendTargetValue)
		end)
	
	FinishLineFrame:AddChild(FinishButton)
	
	NeedMoreButton = AceGUI:Create("Button")
	NeedMoreButton:SetWidth(150)
	NeedMoreButton:SetHeight(50)
	NeedMoreButton:SetText("需要更新")
	NeedMoreButton:SetCallback("OnClick", function(widget)
			SendChatMessageTo("需要最新顏色！", SendTargetValue)
		end)

	FinishLineFrame:AddChild(NeedMoreButton)

	MainFrame:AddChild(FinishLineFrame)

	return MainFrame
end